package RecursionOne;

public class RecursionOneDriver {
	public static void main(String[] args) {
		RecursionOne r = new RecursionOne();
		r.test();
	}
}
