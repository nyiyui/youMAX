package RecursionTwo;

public class RecursionTwoDriver {
	public static void main(String[] args) {
		RecursionTwo r = new RecursionTwo();
		r.test();
	}
}
